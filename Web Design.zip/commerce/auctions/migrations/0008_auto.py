from django.db import migrations, models

# Migrations for url.
class Migration(migrations.Migration):

    dependencies = [
        ('auctions', '0007_auto'),
    ]

    operations = [
        migrations.AlterField(
            model_name='listing',
            name='url',
            field=models.URLField(blank=True),
        ),
    ]
