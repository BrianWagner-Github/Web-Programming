from django.test import TestCase
from django.db.models import Q
from .models import Article


# Create your tests here.

class ModelsTestCase(TestCase):
    def setUp(self) -> None:
        # Create articles
        Article.objects.create(title="Ask a Designer: Improving your home",
                               author="MR",
                               date="Today",
                               brief="When your entire life is happening inside your home",
                               free_text="When your entire life is happening inside your home, it matters how that space feels and functions.",
                               pay_text="Interior designers often focused on this even before self-quarantine, asking clients...")

    def test_articles_count(self):
        articles = Article.objects
        self.assertEqual(articles.count(), 4)

    def test_title_search_count(self):
        article = Article.objects.filter(title__icontains='the')
        article2 = Article.objects.filter(title__icontains=' a ')
        self.assertEqual(article.count(), 0)
        self.assertEqual(article2.count(), 3)

    def test_brief_search_count(self):
        article = Article.objects.filter(brief__icontains='in')
        article2 = Article.objects.filter(brief__icontains='pandemic')
        self.assertEqual(article.count(), 3)
        self.assertEqual(article2.count(), 1)

    def test_union_search_count(self):
        query1 = "coronavirus"
        query2 = "and"
        article = Article.objects.filter(Q(title__icontains=query1) |
                                         Q(free_text__icontains=query1) |
                                         Q(pay_text__icontains=query1))
        article2 = Article.objects.filter(Q(title__icontains=query2) |
                                          Q(free_text__icontains=query2) |
                                          Q(pay_text__icontains=query2))
        self.assertEqual(article.count(), 2)
        self.assertEqual(article2.count(), 4)
