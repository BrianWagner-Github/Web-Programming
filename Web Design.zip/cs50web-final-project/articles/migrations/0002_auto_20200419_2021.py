from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('articles', '0001_initial'),
    ]

    operations = [
        migrations.AlterField(
            model_name='article',
            name='pay_text',
            field=models.TextField(verbose_name='Full part'),
        ),
    ]
