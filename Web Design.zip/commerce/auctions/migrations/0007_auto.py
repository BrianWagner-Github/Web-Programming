from django.db import migrations, models

# Migrations to list winner.
class Migration(migrations.Migration):

    dependencies = [
        ('auctions', '0006_auto'),
    ]

    operations = [
        migrations.AddField(
            model_name='listing',
            name='winner',
            field=models.CharField(default='', max_length=34),
        ),
        migrations.AlterField(
            model_name='listing',
            name='owner',
            field=models.CharField(max_length=34),
        ),
    ]
