from django.db import migrations, models

# Migrations.
class Migration(migrations.Migration):

    dependencies = [
        ('auctions', '0002_bid'),
    ]

    operations = [
        migrations.AlterField(
            model_name='bid',
            name='bid',
            field=models.IntegerField(blank=True, null=True),
        ),
    ]
