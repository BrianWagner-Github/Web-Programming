### Project 0 - Search 

### OVERVIEW 

#### This project aims at designing a front-end for Google Search, Google Image Search, and Google Advanced Search. 

#### User can query text, image or perform an advanced search. Also performs the functionality of "I'm Feeling Lucky" we see on Google. Less focus is given on the designing part and more on the use of GET parameter of URL in order to implement this site.

#### *SCREENCAST -*
Find the video demonstration of my project [here](https://youtu.be/-ttbk3hA9FI)
