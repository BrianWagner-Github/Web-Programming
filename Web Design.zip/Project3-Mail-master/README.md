# Project3 - Mail

Created a mailbox to send emails to people registered on the web app.
Project 3 of the advanced CS50 course called Web Programming with Python and Javascript.

Created with Python, Javascript, HTML and CSS.

Please adhere to the Academic Honesty for the course and do not copy my code.

Developed by Simone Abbamonte, September 2020
