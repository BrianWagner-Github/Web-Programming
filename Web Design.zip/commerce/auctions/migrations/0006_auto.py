from django.db import migrations, models

# Migrations to see the winner.
class Migration(migrations.Migration):

    dependencies = [
        ('auctions', '0005_listing_owner'),
    ]

    operations = [
        migrations.AddField(
            model_name='listing',
            name='active',
            field=models.BooleanField(default=True),
        ),
        migrations.AlterField(
            model_name='bid',
            name='bid',
            field=models.IntegerField(),
        ),
    ]
