
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('customers', '0005_auto_20200421_1116'),
    ]

    operations = [
        migrations.AlterField(
            model_name='customer',
            name='card_balance',
            field=models.IntegerField(null=True, verbose_name='Balance'),
        ),
        migrations.AlterField(
            model_name='customer',
            name='credit_card',
            field=models.CharField(max_length=19, null=True, verbose_name='Credit card'),
        ),
    ]
