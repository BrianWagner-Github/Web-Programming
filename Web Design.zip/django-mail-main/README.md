# Mail
## CS50’s Web Programming with Python and JavaScript
**Video:** https://youtu.be/RbQK0YzQ2z0

Front-end for an email client that makes API calls to send and receive emails.
![1](https://cs50.harvard.edu/web/2020/projects/3/images/inbox.png)
![1](https://cs50.harvard.edu/web/2020/projects/3/images/email.png)

