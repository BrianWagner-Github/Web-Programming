### Project 1 - Wiki 

### OVERVIEW 

#### This project aims at designing a a Wikipedia-like online encyclopedia. 

#### In this site, the user can view the existing web pages on the site to read about them. They can also create a new page as desired and edit it later. <br/> Users can search for a page to query all results of the search. In addition, users can open a random page to read.

### *SCREENCAST -*
Find the video demonstration of my project [here](https://youtu.be/mHUZUWfhrE8)
