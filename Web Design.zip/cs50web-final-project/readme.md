Final Project - FindInBytes

Brian Wagner

Email: Brian_wagner@comcast.net

Project Description:
https://cs50.harvard.edu/extension/web/2021/spring/projects/final/

Goals: Demonstrate course mastery by creating a news website on Django databases that covers global news and finances. 
        Allow subscribers to donate to the website and become subscribers to see premium content.
        Create social media links on the website and make site mobile-friendly.
        Allow editors to edit content and readers to read content based on their statuses.
        The main page has a search bar on articles and randomly selected articles. Login not required for free content. 
        Results page displays articles and content locked behind a paywall. 
        Functional login and shop pages allow user data to be stored along with card information in Django. Errors are accounted for. 

Steps to start:

Use terminal to cd into the final project folder. It should be this:

cd cs50web-final-project

pip install -r requirements.txt

run requirements.txt to make sure you have everything installed.

(Optional) python manage.py createsuperuser 
    
    Enter a username, password, and email. Might have to enter y if password is too weak.
    Note: use /admin after the generated link to access django admin on a superuser account. 

python manage.py runserver 

    Click on the link generated in the terminal and begin to browse my website!

Notes for TA: Originally from my project proposal, FindInBytes was a concept for a news media website giving short stories in small bites.
    I made a few articles covering a wide variety of topics in news including international affairs. 
    I decided to not make it solely a financial website as I was more interested in global news. 
    An article was created that links to websites with stock tickers and cryptocurrencies for the views as the original goal was.
    I was getting too many backend errors when trying to create a direct search from the external apis in urls file so I removed that.
    For potential future projects, I will try to integrate more external APIs. 
    I did include a secret key as covered in the last lecture.
	I added comments so it should be easier to read and understand my reasoning. 

    Some individual file comments: 
    
    Templates folder include some html files. Login and error are fairly straight forward. The base page importantly holds many of my references and I experimented with site description and categorized all my goals so it is easily readable for the user. I linked contact and Github social media as well.

    The static file is fairly straight forward too. I customized it to my liking so all users would see a static setup. The png is a free downloaded globe to represent international news. 
    The majority of my work this project was setting up the shop and articles for customers. The shop is designed to allow subscribers to get access to exclusive content through donations.
    If not a subscriber, content can be hidden by editors by simply putting nothing or the word none in the bottom description when creating articles.
    Through many bug, it finally works well!
    
Thank you for this semester. It was truly a pleasure learning so much. Please connect with my on LinkedIn and have a great year!
https://www.linkedin.com/in/brianwagnerlink/

Requirements
In this project, you are asked to build a web application of your own. The nature of the application is up to you, subject to a few requirements:

Your web application must utilize Django (including at least one model) on the back-end and JavaScript on the front-end.
Your web application must be mobile-responsive.
In a README file (whose extension can be .txt, .md, .adoc, or .pdf) in your project’s main directory, include a full write-up describing your project, what’s contained in each file you created, why you made certain design decisions, and any other additional information the staff should know about your project. This document should be sufficiently thorough for your teaching fellow to run your project without any need to contact you further with questions. Take your time, and do not save this step for last.
If you’ve added any Python packages that need to be installed in order to run your web application, be sure to add them to a requirements.txt file!
Beyond these requirements, the design, look, and feel of the website are up to you!