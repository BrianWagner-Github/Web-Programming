from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('articles', '0002_auto_20200419_2021'),
    ]

    operations = [
        migrations.AddField(
            model_name='article',
            name='author',
            field=models.CharField(max_length=64, null=True, verbose_name='Author'),
        ),
        migrations.AlterField(
            model_name='article',
            name='free_text',
            field=models.TextField(null=True, verbose_name='Free part'),
        ),
        migrations.AlterField(
            model_name='article',
            name='pay_text',
            field=models.TextField(null=True, verbose_name='Full part'),
        ),
    ]
